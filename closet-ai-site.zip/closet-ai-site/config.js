// Cole aqui os dados do seu projeto Supabase (Settings > API). A chave "anon" é pública por design.
window.CLOSET_CONFIG={url:"COLE_A_URL_DO_SUPABASE",key:"COLE_A_CHAVE_ANON"};
