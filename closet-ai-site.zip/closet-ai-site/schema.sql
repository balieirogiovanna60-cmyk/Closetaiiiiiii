-- Cole no SQL Editor do Supabase e execute.
create table items(
  id text primary key,
  user_id uuid not null default auth.uid() references auth.users on delete cascade,
  name text, cat text, color text, style text, season text, occ text[], img text, ts bigint
);
create table state(
  user_id uuid primary key default auth.uid() references auth.users on delete cascade,
  data jsonb not null default '{}'
);
alter table items enable row level security;
alter table state enable row level security;
create policy "minhas pecas" on items for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "meu estado" on state for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
