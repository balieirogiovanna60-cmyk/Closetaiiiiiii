const user=require("../lib/auth");
exports.handler=async e=>{
  const j=(s,b)=>({statusCode:s,headers:{"Content-Type":"application/json"},body:JSON.stringify(b)});
  if(e.httpMethod!=="POST")return j(405,{error:"Método não permitido"});
  if(!process.env.REMOVEBG_API_KEY)return j(501,{error:"REMOVEBG_API_KEY não configurada"});
  if(!(await user(e)))return j(401,{error:"Faça login novamente"});
  const img=String(JSON.parse(e.body).image||"").split(",")[1];
  if(!img)return j(400,{error:"Imagem inválida"});
  const r=await fetch("https://api.remove.bg/v1.0/removebg",{method:"POST",headers:{"X-Api-Key":process.env.REMOVEBG_API_KEY,"Content-Type":"application/json"},
    body:JSON.stringify({image_file_b64:img,size:"auto",bg_color:"ffffff",format:"jpg"})});
  if(!r.ok)return j(502,{error:"Falha ao remover o fundo"});
  return j(200,{image:"data:image/jpeg;base64,"+Buffer.from(await r.arrayBuffer()).toString("base64")});
};
