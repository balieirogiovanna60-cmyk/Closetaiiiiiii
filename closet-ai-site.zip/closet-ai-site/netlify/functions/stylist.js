const user=require("../lib/auth");
exports.handler=async e=>{
  const j=(s,b)=>({statusCode:s,headers:{"Content-Type":"application/json"},body:JSON.stringify(b)});
  if(e.httpMethod!=="POST")return j(405,{error:"Método não permitido"});
  if(!process.env.ANTHROPIC_API_KEY)return j(501,{error:"ANTHROPIC_API_KEY não configurada"});
  if(!(await user(e)))return j(401,{error:"Faça login novamente"});
  let prompt;try{prompt=String(JSON.parse(e.body).prompt||"").slice(0,3000)}catch{return j(400,{error:"Pedido inválido"})}
  const r=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"x-api-key":process.env.ANTHROPIC_API_KEY,"anthropic-version":"2023-06-01","content-type":"application/json"},
    body:JSON.stringify({model:"claude-sonnet-5-5",max_tokens:500,messages:[{role:"user",content:prompt}]})});
  const d=await r.json();
  if(!r.ok)return j(502,{error:d.error?.message||"Falha na IA"});
  return j(200,{text:d.content.filter(c=>c.type==="text").map(c=>c.text).join("\n")});
};
