# Closet AI — passo a passo (iniciante)

Site real: login por e-mail e senha, banco de dados, roupas salvas por usuário, IA de stylist e remoção de fundo.
Custo para começar: planos gratuitos do Supabase e do Netlify (a IA e a remoção de fundo são pagas por uso).

## 1. Banco e login (Supabase)
1. Crie uma conta e um projeto em supabase.com.
2. Abra **SQL Editor**, cole o conteúdo de `schema.sql` e execute.
3. Em **Settings > API** copie a **Project URL** e a chave **anon public**.
4. Cole os dois valores em `config.js`.
5. Em **Authentication > Providers > Email** você pode desligar "Confirm email" para testar sem confirmar e-mail.

## 2. Publicar (Netlify)
1. Em netlify.com, crie um site enviando esta pasta (ou conecte um repositório do GitHub).
2. Em **Site configuration > Environment variables** crie:
   - `SUPABASE_URL` e `SUPABASE_ANON_KEY` (os mesmos valores do passo 1) — obrigatórias para as funções.
   - `ANTHROPIC_API_KEY` (console.anthropic.com) — liga a stylist com IA.
   - `REMOVEBG_API_KEY` (remove.bg) — liga a remoção automática de fundo. Opcional.
3. Faça um novo deploy. Abra o endereço do site, crie sua conta e cadastre as roupas.

## Observações
- Sem as chaves opcionais o site funciona; só a stylist com IA e a remoção de fundo ficam desligadas, com aviso na tela.
- As fotos ficam no próprio banco, reduzidas a ~420 px. Para milhares de peças, migre para o Supabase Storage.
- As combinações usam regras de cor e etiquetas; a IA só escreve a explicação da stylist.
